<!DOCTYPE html>
<html>
<body>

<h2>Login Form</h2>

<form action="LoginAction.php" method="POST">
  <label for="fname">Name:</label><br>
  <input type="text" id="fname" name="fname" ><br>
  <label for="password">Password:</label><br>
  <input type="password" id="password" name="password" ><br><br>
  <input type="submit" value="Submit">
</form> 



</body>
</html>