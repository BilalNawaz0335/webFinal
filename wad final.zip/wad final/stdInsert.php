<?php

$stdName = $_POST['stdName'];
$stdEmail = $_POST['stdEmail'];
$stdDOB = $_POST['stdDOB'];
$stdCNIC = $_POST['stdCNIC'];
$stdFees = 0;
if($_POST['stdFees']=='Paid')
    $stdFees = 1;
$stdClass = $_POST['stdClass'];
$stdDegree = $_POST['degree'];


$con = new mysqli("localhost","root","","bscsfinaldb");


if(isset($_POST['stdReg']))
{

    $q1="
    INSERT INTO `stdpgc`(`stdName`, `stdEmail`, `stdDOB`, `stdCNIC`, `stdFees`, `stdClass`, `stdDegree`)
    VALUES ('$stdName','$stdEmail','$stdDOB','$stdCNIC','$stdFees','$stdClass','$stdDegree')";

    $con->query($q1);
    header("location:studentReg.php");

}

if(isset($_POST['update-data']))
{
    $id= $_POST["id"];
    echo $id;
    $q1=" 
        UPDATE `stdpgc` SET `stdName`='$stdName',`stdEmail`='$stdEmail',
            `stdDOB`='$stdDOB',`stdCNIC`='$stdCNIC',`stdFees`='$stdFees',`stdClass`='$stdClass',
                `stdDegree`='$stdDegree' WHERE id = $id ";
    $con->query($q1);
    header("location:record.php");
    
}

?>