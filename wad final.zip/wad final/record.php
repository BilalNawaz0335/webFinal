<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Data</title>
</head>

<body>
    <table border="1">
        <thead>
            <td>id</td>
            <td>stdName</td>
            <td>stdEmail</td>
            <td>stdDOB</td>
            <td>stdCNIC</td>
            <td>stdFees</td>
            <td>stdClass</td>
            <td>stdDegree</td>
        </thead>
        <?php
        $con = new mysqli("localhost","root","","bscsfinaldb");
        $q1='select * from stdpgc';
        $resultSet=$con->query($q1);
        while($row=$resultSet->fetch_assoc()){
            echo '<tr>';
                echo '<td>';
                    echo $row["id"];
                echo '</td>';

                echo '<td>';
                    echo $row["stdName"];
                echo '</td>';
            
                echo '<td>';
                    echo $row["stdEmail"];
                echo '</td>';

                echo '<td>';
                    echo $row["stdDOB"];
                echo '</td>';

                echo '<td>';
                    echo $row["stdCNIC"];
                echo '</td>';

                echo '<td>';
                    echo $row["stdFees"];
                echo '</td>';

                echo '<td>';
                    echo $row["stdClass"];
                echo '</td>';

                echo '<td>';
                    echo $row["stdDegree"];
                echo '</td>';

                echo '<td>';
                    echo $row["stdDegree"];
                echo '</td>';

                echo '<td>';
                    echo '<form action="modify.php" method="post">';
                        echo '<input type="hidden" name="id" value="'.$row["id"].'">';
                        echo '<input type="submit" name="update" value="update">';
                        echo '<input type="submit" name="delete" value="delete">';
                    echo '</form>';
                echo '</td>';

            echo '</tr>';
        }
        ?>
    </table>
    <br>
    <a href="./index.php">Main Page</a>





</body>
</html>