<?php

$id = $_POST['id'];
if(isset($_POST['update']))
{
    echo'<form action="stdInsert.php" method="post">
    Name: <input type = "text" name="stdName" placeholder="enter name"><br>
    Email: <input type = "email" name="stdEmail" placeholder="enter email"><br>
    DOB: <input type="text" pattern="\d{2}-\d{2}-\d{4}" name="stdDOB" placeholder="MM-DD-YYYY"><br>
    CNIC: <input type = "text" pattern="\d{5}-\d{7}-\d" name="stdCNIC" placeholder="xxxxx-xxxxxxx-x"><br>
    Fee Status: <select name="stdFees">
        <option>Paid</option>
        <option>Unpaid</option>
    </select><br>
    Class: <input type="text" name="stdClass"><br>
    Degree: <select name="degree">
        <option >ADP</option>
        <option >BSCS</option>
        <option >BSSE</option>
    </select><br>
    
    <input type="submit" name="update-data" >
    <input type="hidden" name="id" value="'. $id .'">
</form><br>';
}

else
{
   
    $con = new mysqli("localhost","root","","bscsfinaldb");
    $q1 = "
        DELETE FROM `stdpgc` WHERE id= $id";

    $con->query($q1);
    header("location:record.php");
}

?>